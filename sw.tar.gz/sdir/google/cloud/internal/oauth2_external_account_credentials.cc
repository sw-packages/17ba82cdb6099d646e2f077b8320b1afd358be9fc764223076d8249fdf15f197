// Copyright 2022 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "google/cloud/internal/oauth2_external_account_credentials.h"
#include "google/cloud/internal/base64_transforms.h"
#include "google/cloud/internal/external_account_token_source_aws.h"
#include "google/cloud/internal/external_account_token_source_file.h"
#include "google/cloud/internal/external_account_token_source_url.h"
#include "google/cloud/internal/json_parsing.h"
#include "google/cloud/internal/make_status.h"
#include "google/cloud/internal/oauth2_credential_constants.h"
#include "google/cloud/internal/oauth2_minimal_iam_credentials_rest.h"
#include "google/cloud/internal/oauth2_universe_domain.h"
#include "google/cloud/internal/parse_rfc3339.h"
#include "google/cloud/internal/rest_client.h"
#include "absl/strings/str_cat.h"
#include "absl/strings/str_split.h"
#include <nlohmann/json.hpp>
#include <mutex>
#include <regex>

namespace google {
namespace cloud {
namespace oauth2_internal {
GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_BEGIN
namespace {

using ::google::cloud::internal::InvalidArgumentError;

StatusOr<ExternalAccountTokenSource> MakeExternalAccountTokenSource(
    nlohmann::json const& credentials_source, std::string const& audience,
    internal::ErrorContext const& ec) {
  auto source =
      MakeExternalAccountTokenSourceAws(credentials_source, audience, ec);
  if (source) return source;
  source = MakeExternalAccountTokenSourceUrl(credentials_source, ec);
  if (source) return source;
  source = MakeExternalAccountTokenSourceFile(credentials_source, ec);
  if (source) return source;
  return InvalidArgumentError(
      "unknown subject token source for external account",
      GCP_ERROR_INFO().WithContext(ec));
}

std::variant<std::monostate, WorkforceIdentityFederationInfo,
             WorkloadIdentityFederationInfo>
IdentityFederationFromAudience(std::string const& audience) {
  auto constexpr kWorkloadPattern =
      R"""(iam.googleapis.com/projects/([^/]+)/locations/global/workloadIdentityPools/([^/]+)/)""";
  static auto* workload_re =
      new std::regex{kWorkloadPattern, std::regex::optimize};

  auto constexpr kWorkforcePattern =
      R"""(iam.googleapis.com/locations/global/workforcePools/([^/]+)/)""";
  static auto* workforce_re =
      new std::regex{kWorkforcePattern, std::regex::optimize};

  std::smatch match;
  if (std::regex_search(audience, match, *workload_re)) {
    return WorkloadIdentityFederationInfo{match[1], match[2]};
  }
  if (std::regex_search(audience, match, *workforce_re)) {
    return WorkforceIdentityFederationInfo{match[1]};
  }
  return std::monostate{};
}

}  // namespace

bool ExternalAccountInfo::IsWorkforceIdentityFederation() const {
  return std::holds_alternative<WorkforceIdentityFederationInfo>(
      identity_federation_info);
}

bool ExternalAccountInfo::IsWorkloadIdentityFederation() const {
  return std::holds_alternative<WorkloadIdentityFederationInfo>(
      identity_federation_info);
}

StatusOr<std::optional<ExternalAccountImpersonationConfig>>
GetExternalAccountImpersonationConfiguration(
    nlohmann::json const& configuration, internal::ErrorContext const& ec) {
  auto constexpr kDefaultImpersonationTokenLifetime =
      std::chrono::seconds(3600);
  auto impersonation_config =
      StatusOr<std::optional<ExternalAccountImpersonationConfig>>(std::nullopt);
  auto it = configuration.find("service_account_impersonation_url");
  if (it == configuration.end()) return impersonation_config;
  if (!it->is_string()) {
    return InvalidTypeError("service_account_impersonation_url",
                            "credentials-file", ec);
  }

  // AIP-4117 https://google.aip.dev/auth/4117 specifies the
  // service_account_impersonation_url ends with "<email>:generateAccessToken".
  std::string url = it->get<std::string>();
  std::vector<std::string_view> pieces = absl::StrSplit(url, '/');
  std::string email;
  for (auto const& p : pieces) {
    if (absl::StrContains(p, ":")) {
      std::vector<std::string_view> t = absl::StrSplit(p, ':');
      email = t.front();
    }
  }

  if (email.empty()) {
    return InvalidArgumentError(
        "invalid service_account_impersonation_url; must conform to AIP-4117",
        GCP_ERROR_INFO()
            .WithMetadata("service_account_impersonation_url", url)
            .WithContext(ec));
  }

  impersonation_config = ExternalAccountImpersonationConfig{
      std::move(url), std::move(email), kDefaultImpersonationTokenLifetime};

  it = configuration.find("service_account_impersonation");
  if (it == configuration.end()) return impersonation_config;
  if (!it->is_object()) {
    return InvalidTypeError("service_account_impersonation", "credentials-file",
                            ec);
  }
  auto lifetime = ValidateIntField(
      it.value(), "token_lifetime_seconds",
      "credentials-file.service_account_impersonation",
      static_cast<std::int32_t>(kDefaultImpersonationTokenLifetime.count()),
      ec);
  if (!lifetime) return std::move(lifetime).status();
  (*impersonation_config)->token_lifetime = std::chrono::seconds(*lifetime);

  return impersonation_config;
}

/// Parse a JSON string with an external account configuration.
StatusOr<ExternalAccountInfo> ParseExternalAccountConfiguration(
    std::string const& configuration, internal::ErrorContext const& ec) {
  auto json = nlohmann::json::parse(configuration, nullptr, false);
  if (!json.is_object()) {
    return InvalidArgumentError(
        "external account configuration was not a JSON object",
        GCP_ERROR_INFO().WithContext(ec));
  }
  auto type = ValidateStringField(json, "type", "credentials-file", ec);
  if (!type) return std::move(type).status();
  if (*type != "external_account" &&
      *type != "external_account_authorized_user") {
    return InvalidArgumentError(
        "mismatched type (" + *type + ") in external account configuration",
        GCP_ERROR_INFO().WithContext(ec));
  }
  auto token_url =
      ValidateStringField(json, "token_url", "credentials-file", ec);
  if (!token_url) return std::move(token_url).status();
  auto universe_domain = GetUniverseDomainFromCredentialsJson(json);
  if (!universe_domain) return std::move(universe_domain).status();

  if (*type == "external_account_authorized_user") {
    StatusOr<std::string> client_id =
        ValidateStringField(json, "client_id", "credentials-file", ec);
    if (!client_id) return std::move(client_id).status();
    StatusOr<std::string> client_secret =
        ValidateStringField(json, "client_secret", "credentials-file", ec);
    if (!client_secret) return std::move(client_secret).status();
    StatusOr<std::string> refresh_token =
        ValidateStringField(json, "refresh_token", "credentials-file", ec);
    if (!refresh_token) return std::move(refresh_token).status();
    StatusOr<std::string> audience =
        ValidateStringField(json, "audience", "credentials-file", "", ec);
    if (!audience) return std::move(audience).status();
    std::variant<std::monostate, WorkforceIdentityFederationInfo,
                 WorkloadIdentityFederationInfo>
        identity_federation = IdentityFederationFromAudience(*audience);

    return ExternalAccountInfo{
        *std::move(audience),
        {},
        *std::move(token_url),
        {},
        std::nullopt,
        *std::move(universe_domain),
        std::nullopt,
        std::move(identity_federation),
        ExternalAccountAuthorizedUserInfo{*std::move(client_id),
                                          *std::move(client_secret),
                                          *std::move(refresh_token)}};
  }

  auto audience = ValidateStringField(json, "audience", "credentials-file", ec);
  if (!audience) return std::move(audience).status();
  auto identity_federation = IdentityFederationFromAudience(*audience);

  auto subject_token_type =
      ValidateStringField(json, "subject_token_type", "credentials-file", ec);
  if (!subject_token_type) return std::move(subject_token_type).status();

  auto credential_source = json.find("credential_source");
  if (credential_source == json.end()) {
    return InvalidArgumentError(
        "missing `credential_source` field in external account configuration",
        GCP_ERROR_INFO().WithContext(ec));
  }
  if (!credential_source->is_object()) {
    return InvalidArgumentError(
        "`credential_source` field is not a JSON object in external account "
        "configuration",
        GCP_ERROR_INFO().WithContext(ec));
  }

  auto source =
      MakeExternalAccountTokenSource(*credential_source, *audience, ec);
  if (!source) return std::move(source).status();

  std::optional<std::string> workforce_pool_user_project;
  auto it = json.find("workforce_pool_user_project");
  if (it != json.end()) {
    workforce_pool_user_project = it->get<std::string>();
  }

  auto info = ExternalAccountInfo{*std::move(audience),
                                  *std::move(subject_token_type),
                                  *std::move(token_url),
                                  *std::move(source),
                                  std::nullopt,
                                  *std::move(universe_domain),
                                  std::move(workforce_pool_user_project),
                                  std::move(identity_federation)};

  auto impersonate_config =
      GetExternalAccountImpersonationConfiguration(json, ec);

  if (!impersonate_config.ok()) return impersonate_config.status();
  info.impersonation_config = *std::move(impersonate_config);
  return info;
}

ExternalAccountCredentials::ExternalAccountCredentials(
    ExternalAccountInfo info, HttpClientFactory client_factory, Options options)
    : info_(std::move(info)),
      client_factory_(std::move(client_factory)),
      options_(std::move(options)) {}

StatusOr<AccessToken> ExternalAccountCredentials::GetToken(
    std::chrono::system_clock::time_point tp) {
  if (info_.authorized_user_info.has_value()) {
    return GetTokenAuthorizedUser(tp);
  }
  auto subject_token = (info_.token_source)(client_factory_, options_);
  if (!subject_token) return std::move(subject_token).status();

  auto form_data = std::vector<std::pair<std::string, std::string>>{
      {"grant_type", "urn:ietf:params:oauth:grant-type:token-exchange"},
      {"requested_token_type", "urn:ietf:params:oauth:token-type:access_token"},
      {"scope", "https://www.googleapis.com/auth/cloud-platform"},
      {"audience", info_.audience},
      {"subject_token_type", info_.subject_token_type},
      {"subject_token", subject_token->token},
  };

  // Workforce Identity is handled at the org level and requires the userProject
  // header. Workload Identity is handled at the project level and doesn't
  // require the header.
  if (info_.IsWorkforceIdentityFederation() &&
      info_.workforce_pool_user_project.has_value()) {
    form_data.emplace_back(
        "options", absl::StrCat(R"({"userProject": ")",
                                *info_.workforce_pool_user_project, R"("})"));
  }

  auto request =
      rest_internal::RestRequest(info_.token_url)
          .AddHeader("content-type", "application/x-www-form-urlencoded");

  auto client = client_factory_(options_);
  rest_internal::RestContext unused;
  auto response = client->Post(unused, request, form_data);
  if (!response) return std::move(response).status();
  if (IsHttpError(**response)) return AsStatus(std::move(**response));
  auto payload = rest_internal::ReadAll(std::move(**response).ExtractPayload());
  if (!payload) return std::move(payload).status();

  auto ec = internal::ErrorContext({
      {"audience", info_.audience},
      {"subject_token_type", info_.subject_token_type},
      {"subject_token", subject_token->token.substr(0, 32)},
      {"token_url", info_.token_url},
  });

  auto access = nlohmann::json::parse(*payload, nullptr, false);
  if (!access.is_object()) {
    return InvalidArgumentError(
        "token exchange response cannot be parsed as JSON object",
        GCP_ERROR_INFO().WithContext(ec));
  }
  auto token = ValidateStringField(access, "access_token",
                                   "token-exchange-response", ec);
  if (!token) return std::move(token).status();
  auto issued_token_type = ValidateStringField(access, "issued_token_type",
                                               "token-exchange-response", ec);
  if (!issued_token_type) return std::move(issued_token_type).status();
  auto token_type =
      ValidateStringField(access, "token_type", "token-exchange-response", ec);
  if (!token_type) return std::move(token_type).status();

  if (*issued_token_type != "urn:ietf:params:oauth:token-type:access_token" ||
      *token_type != "Bearer") {
    return InvalidArgumentError(
        "expected a Bearer access token in token exchange response",
        GCP_ERROR_INFO()
            .WithContext(std::move(ec))
            .WithMetadata("token_type", *token_type)
            .WithMetadata("issued_token_type", *issued_token_type));
  }
  if (info_.impersonation_config.has_value()) {
    return GetTokenImpersonation(*token, ec);
  }

  auto expires_in =
      ValidateIntField(access, "expires_in", "token-exchange-response", ec);
  if (!expires_in) return std::move(expires_in).status();
  return AccessToken{*token, tp + std::chrono::seconds(*expires_in)};
}

Credentials::AllowedLocationsRequestType
ExternalAccountCredentials::AllowedLocationsRequest() const {
  Credentials::AllowedLocationsRequestType request = std::monostate{};
  // TODO(#16079): Remove conditional and else clause when GA.
#ifdef GOOGLE_CLOUD_CPP_TESTING_ENABLE_RAB
  if (info_.impersonation_config.has_value()) {
    request = ServiceAccountAllowedLocationsRequest{
        info_.impersonation_config->email};
  } else if (info_.IsWorkforceIdentityFederation()) {
    auto wif = std::get<WorkforceIdentityFederationInfo>(
        info_.identity_federation_info);
    request = WorkforceIdentityAllowedLocationsRequest{wif.pool_id};
  } else if (info_.IsWorkloadIdentityFederation()) {
    auto wif = std::get<WorkloadIdentityFederationInfo>(
        info_.identity_federation_info);
    request =
        WorkloadIdentityAllowedLocationsRequest{wif.project_id, wif.pool_id};
  }
#endif
  return request;
}

StatusOr<AccessToken> ExternalAccountCredentials::GetTokenImpersonation(
    std::string const& access_token, internal::ErrorContext const& ec) {
  auto request = rest_internal::RestRequest(info_.impersonation_config->url);
  request.AddHeader("Authorization", absl::StrCat("Bearer ", access_token));
  request.AddHeader("Content-Type", "application/json");
  auto const lifetime = info_.impersonation_config->token_lifetime;
  auto request_payload = nlohmann::json{
      {"delegates", nlohmann::json::array()},
      {"scope", nlohmann::json::array({GoogleOAuthScopeCloudPlatform()})},
      {"lifetime", std::to_string(lifetime.count()) + "s"}};

  auto client = client_factory_(options_);
  rest_internal::RestContext context;
  auto response = client->Post(context, request, {request_payload.dump()});
  if (!response) return std::move(response).status();
  return ParseGenerateAccessTokenResponse(**response, ec);
}

StatusOr<AccessToken> ExternalAccountCredentials::GetTokenAuthorizedUser(
    std::chrono::system_clock::time_point tp) {
  std::string current_refresh_token;
  {
    std::lock_guard<std::mutex> lk(mu_);
    current_refresh_token = info_.authorized_user_info->refresh_token;
  }
  internal::Base64Encoder encoder;
  for (unsigned char const c :
       absl::StrCat(info_.authorized_user_info->client_id, ":",
                    info_.authorized_user_info->client_secret)) {
    encoder.PushBack(c);
  }
  rest_internal::RestRequest request =
      rest_internal::RestRequest(info_.token_url)
          .AddHeader("content-type", "application/x-www-form-urlencoded")
          .AddHeader("Authorization",
                     absl::StrCat("Basic ", std::move(encoder).FlushAndPad()));

  std::vector<std::pair<std::string, std::string>> form_data = {
      {"grant_type", "refresh_token"},
      {"refresh_token", std::move(current_refresh_token)},
  };

  std::unique_ptr<rest_internal::RestClient> client = client_factory_(options_);
  rest_internal::RestContext unused;
  StatusOr<std::unique_ptr<rest_internal::RestResponse>> response =
      client->Post(unused, request, form_data);
  if (!response) return std::move(response).status();
  if (IsHttpError(**response)) return AsStatus(std::move(**response));
  StatusOr<std::string> payload =
      rest_internal::ReadAll(std::move(**response).ExtractPayload());
  if (!payload) return std::move(payload).status();

  internal::ErrorContext const ec(
      internal::ErrorContext::Container{{"token_url", info_.token_url}});

  nlohmann::json access = nlohmann::json::parse(*payload, nullptr, false);
  if (!access.is_object()) {
    return InvalidArgumentError(
        "token refresh response cannot be parsed as JSON object",
        GCP_ERROR_INFO().WithContext(ec));
  }
  StatusOr<std::string> token =
      ValidateStringField(access, "access_token", "token-refresh-response", ec);
  if (!token) return std::move(token).status();
  StatusOr<std::int32_t> expires_in =
      ValidateIntField(access, "expires_in", "token-refresh-response", ec);
  if (!expires_in) return std::move(expires_in).status();
  StatusOr<std::string> new_refresh_token = ValidateStringField(
      access, "refresh_token", "token-refresh-response", "", ec);
  if (!new_refresh_token) return std::move(new_refresh_token).status();
  if (!new_refresh_token->empty()) {
    std::lock_guard<std::mutex> lk(mu_);
    info_.authorized_user_info->refresh_token = *std::move(new_refresh_token);
  }
  return AccessToken{*std::move(token), tp + std::chrono::seconds(*expires_in)};
}

GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_END
}  // namespace oauth2_internal
}  // namespace cloud
}  // namespace google
